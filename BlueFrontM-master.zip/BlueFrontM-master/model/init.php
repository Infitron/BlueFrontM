<?php
	error_reporting(1);
	require_once("session.php");
	require_once("Api.php");
	require_once("auto_function.php");
	require_once("user.php");
	require_once("category.php");
	require_once("subcategory.php");
	require_once("location.php");
	require_once("service.php");
	require_once("bank_code.php");
	require_once("bank_details.php");
	require_once("complaint.php");
	require_once("state.php");
	require_once("search.php");
	require_once("order.php");

	//require_once("test.php");
	


?>