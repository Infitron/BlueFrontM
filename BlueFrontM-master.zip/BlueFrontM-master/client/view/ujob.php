                        
                       <div class="row">
                            <div class="col-md-12">
                                <div class="overview-wrap">
                                    <h2 class="title-1">Orders Request</h2>
                                    <!--<a href="index.php?auj" class="au-btn au-btn-icon au-btn--blue">
                                        <i class="zmdi zmdi-plus"></i>add Job Request</a>-->
                                </div>
                            </div>
                        </div>
                        <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>S/N</th>
                                                <th>User Name</th>
                                                <th>User Type</th>
                                                <th>Product / Service</th>
                                                <th>Category</th>
                                                <th>Order Status</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td>Max Mayowa</td>
                                                <td>Artisan</td>
                                                <td>Computer</td>
                                                <td>Electricial Electronics</td>
                                                <td>Processing</td>
                                            </tr>

                                        </tbody>
                                    </table>
                                </div>
                                <!-- END DATA TABLE-->
                            </div>
                        </div>