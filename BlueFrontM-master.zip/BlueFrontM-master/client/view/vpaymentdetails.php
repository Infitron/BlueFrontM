                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <strong>View User </strong>
                                        <small>Payment Details </small>
                                    </div>
                                    <div class="card-body card-block">
                                        <form>
                                            
                                        <div class="form-group">
                                            <label for="name" class=" form-control-label">Artisan Name</label>
                                            <input type="text" id="name" placeholder="" class="form-control" readonly="">
                                        </div>
                                        <div class="form-group">
                                            <label for="service" class=" form-control-label">Product / Service</label>
                                            <input type="text" id="service" name="service" placeholder="" class="form-control" readonly="">
                                        </div>
                                        <div class="form-group">
                                            <label for="category" class=" form-control-label">Category</label>
                                            <input type="text" id="category" name="category" placeholder="" class="form-control" readonly="">
                                        </div>
                                        <div class="form-group">
                                            <label for="category" class=" form-control-label">Sub Category</label>
                                            <input type="text" id="subcategory" name="subcategory" placeholder="" class="form-control" readonly="">
                                        </div>
                                        <div class="form-group">
                                            <label for="category" class=" form-control-label">Amount</label>
                                            <input type="text" id="amount" name="amount" placeholder="" class="form-control" readonly="">
                                        </div>
                                        <div class="form-group">
                                            <label for="category" class=" form-control-label">Payment Date</label>
                                            <input type="text" id="amount" name="amount" placeholder="" class="form-control" readonly="">
                                        </div>
                                        
                                        </form>
                                       
                                    </div>
                                </div>
                            </div>