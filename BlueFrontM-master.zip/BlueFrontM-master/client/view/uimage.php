                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <strong>User</strong>
                                        <small>Upload Image</small>
                                    </div>
                                    <div class="card-body card-block">
                                        <form>
                        

                                         <div class="form-group">
                                            <label for="ufile" class=" form-control-label">User Picture Upload</label>
                                            <input type="file" id="ufile" placeholder="" name="ufile" class="form-control" >
                                        </div>
                                                 <div class="form-group">
                                                     <button type="submit" class="btn btn-primary btn-lg">Submit</button>
                                                </div>
                                        </form>
                                       
                                    </div>
                                </div>
                            </div>